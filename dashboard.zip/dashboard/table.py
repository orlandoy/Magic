from dash import dash_table

def create_data_table(df, color_scheme):
    return dash_table.DataTable(
        id="data-table",
        columns=[{"name": col, "id": col} for col in df.columns],
        data=df.to_dict("records"),
        style_table={"overflowX": "auto", "borderRadius": "12px"},
        style_header={
            "backgroundColor": color_scheme["highlight"],
            "color": "white",
            "fontWeight": "bold",
            "fontSize": "16px",
            "border": "none"
        },
        style_cell={
            "textAlign": "left",
            "padding": "14px",
            "fontFamily": "Roboto",
            "backgroundColor": color_scheme["card"],
            "color": color_scheme["text"]
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "#243447"},
            {"if": {"filter_query": "{状态} = '已完成'"}, "color": color_scheme["已完成"][0]},
            {"if": {"filter_query": "{状态} = '进行中'"}, "color": color_scheme["进行中"][0]}
        ],
        filter_action="native",
        sort_action="native",
        page_size=10,
        style_as_list_view=True
    )

