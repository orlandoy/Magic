from dash import html, dcc

def create_card(title, value, icon, color, color_scheme):
    return html.Div(
        className="card",
        style={
            "backgroundColor": color_scheme["card"],
            "borderRadius": "16px",
            "padding": "20px",
            "boxShadow": "0 8px 20px rgba(0,0,0,0.3)",
            "margin": "10px",
            "flex": 1,
            "minWidth": "220px"
        },
        children=[
            html.Div([
                html.I(className=f"fas fa-{icon}", 
                       style={"color": color, "fontSize": "26px"}),
                html.H3(title, style={"marginLeft": "12px", "color": color_scheme["text"]})
            ], style={"display": "flex", "alignItems": "center"}),
            html.H2(
                f"{value:,}",
                style={"color": color, "marginTop": "10px", "fontSize": "30px"}
            )
        ]
    )

def create_layout(df, color_scheme, create_card, create_bar_chart, create_data_table):
    return html.Div(
        style={
            "backgroundColor": color_scheme["background"],
            "minHeight": "100vh",
            "padding": "30px",
            "fontFamily": "Roboto"
        },
        children=[
            html.H1(
                "A2项目数据采集未来看板",
                style={
                    "textAlign": "center",
                    "color": color_scheme["text"],
                    "marginBottom": "40px"
                }
            ),

            html.Div([
                create_card("总采集量", df["采集数量"].sum(), 
                            "database", color_scheme["highlight"], color_scheme),
                create_card("已完成项目", len(df[df["状态"] == "已完成"]), 
                            "check-circle", color_scheme["已完成"][0], color_scheme),
                create_card("进行中项目", len(df[df["状态"] == "进行中"]), 
                            "spinner", color_scheme["进行中"][0], color_scheme)
            ], style={"display": "flex", "flexWrap": "wrap", "marginBottom": "40px"}),

            html.Div(
                className="chart-card",
                style={
                    "backgroundColor": color_scheme["card"],
                    "borderRadius": "16px",
                    "padding": "20px",
                    "boxShadow": "0 8px 20px rgba(0,0,0,0.3)",
                    "marginBottom": "40px"
                },
                children=[
                    dcc.Graph(
                        id="collection-chart",
                        figure=create_bar_chart(df, color_scheme),
                        config={"displayModeBar": False},
                        style={"height": "480px"}
                    )
                ]
            ),

            html.Div(
                className="image-gallery",
                style={
                    "display": "flex",
                    "gap": "20px",
                    "flexWrap": "wrap",
                    "marginBottom": "40px"
                },
                children=[
                    html.Div([
                        html.Img(src=row["图片链接"], style={
                            "width": "100%", "borderRadius": "12px",
                            "boxShadow": "0 4px 10px rgba(0,0,0,0.4)"
                        }),
                        html.H4(row["项目名称"], style={
                            "color": color_scheme["text"],
                            "marginTop": "8px",
                            "textAlign": "center"
                        })
                    ], style={"flex": "1", "minWidth": "300px", "maxWidth": "400px"})
                    for _, row in df.iterrows()
                ]
            ),

            html.Div(
                className="table-card",
                style={
                    "backgroundColor": color_scheme["card"],
                    "borderRadius": "16px",
                    "padding": "20px",
                    "boxShadow": "0 8px 20px rgba(0,0,0,0.3)"
                },
                children=[create_data_table(df, color_scheme)]
            )
        ]
    )

