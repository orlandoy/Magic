import plotly.graph_objects as go

def create_bar_chart(df, color_scheme):
    fig = go.Figure()

    for status in df["状态"].unique():
        df_filtered = df[df["状态"] == status]
        fig.add_trace(go.Bar(
            x=df_filtered["项目名称"],
            y=df_filtered["采集数量"],
            name=status,
            marker=dict(
                color=color_scheme[status][0],
                line=dict(color=color_scheme[status][1], width=2.5),
            ),
            opacity=0.95,
            text=[f"{x:,}" for x in df_filtered["采集数量"]],
            textposition="outside",
            width=0.5
        ))

    avg_value = df["采集数量"].mean()

    fig.update_layout(
        plot_bgcolor=color_scheme["card"],
        paper_bgcolor=color_scheme["background"],
        font=dict(family="Roboto", size=13, color=color_scheme["text"]),
        xaxis=dict(tickangle=-20, showgrid=False),
        yaxis=dict(gridcolor="#34495E", tickformat=","),
        hoverlabel=dict(bgcolor="#2C3E50", font_size=12, font_color="white"),
        legend=dict(orientation="h", y=1.1),
        margin=dict(t=40),
        transition={"duration": 500}
    )

    fig.add_hline(
        y=avg_value,
        line_dash="dot",
        line_color="#BDC3C7",
        annotation_text=f"平均值: {avg_value:,.0f}",
        annotation_font_color=color_scheme["text"]
    )

    return fig

