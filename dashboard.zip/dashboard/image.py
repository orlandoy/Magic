def load_projects():
    return [
        {
            "项目名称": "水果分拣(fruit sort)",
            "采集时间": "2025.04.03-2025.04.20",
            "采集数量": 23618,
            "状态": "已完成",
            "上传": "进行中",
            "图片链接": "https://via.placeholder.com/400x200.png?text=水果分拣"
        },
        {
            "项目名称": "扫码枪扫货(Scanning gun to scan goods)",
            "采集时间": "2025.04.21-2025.04.22",
            "采集数量": 6792,
            "状态": "已完成",
            "上传": "进行中",
            "图片链接": "https://via.placeholder.com/400x200.png?text=扫码枪扫货"
        },
        {
            "项目名称": "桌面垃圾清理(desktop junk cleaning)",
            "采集时间": "2025.04.23-",
            "采集数量": 0,
            "状态": "进行中",
            "上传": "进行中",
            "图片链接": "https://via.placeholder.com/400x200.png?text=桌面垃圾清理"
        },
    ]

